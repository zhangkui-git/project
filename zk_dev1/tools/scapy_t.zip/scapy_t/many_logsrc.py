from scapy.all import *
from scapy.layers.inet import *
import time
from log2file import *
# with open("./V2R1_7.txt",  encoding='utf-8') as file:
#     num = 1
#     for item in file:
#         # print(file.readline())
#         print(f"{num}行",  type(item), item)
#         num += 1


def putudp():
    for item in open("./V2R1_7.txt",  encoding='utf-8'):
        mip = [f"192.168.51.{i}" for i in range(1, 40)]
        start_time = time.time()
        for ip in mip:
            send(Ether(src='', dst='') / IP(src=ip, dst='192.168.100.149') / UDP(sport=random.randint(100, 20000), dport=514) / item)
        end_time = time.time()
        sleep1 = end_time - start_time
        if sleep1 < 1:
            sleep2 = 1 - sleep1
            time.sleep(sleep2)
            # print(f"等待时长为{sleep2}")
            logging.info(f"等待时长为{sleep2}")


if __name__ == '__main__':
    num = 1
    sum1 = 10
    while num < sum1:
        putudp()
        num += 1

