ip = '192.168.4.250'
host = f'https://{ip}:8440'


user = 'op10'
pas = 'Admin@123456'



